# DDForum

DDForum is a PHP based forum software application that's designed like a CMS making it very easy to use and manage.

## Requirements

- PHP 5.6
- MySQL / MariaDB database

## Contributing

Thank you for your interest in contributing to improve and/or fix DDForum, to do so you can report an issue (a bug, feature request...) or fork the repository, modify on your fork then request a merge.

## License

DDForum is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).

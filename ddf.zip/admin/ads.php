<?php

/** Load admin **/
require_once( dirname( __FILE__ ) . '/admin.php' );

$title = 'Manage Ads';
$parent_menu = 'ads.php';
$file = 'ads.php';

require_once( DDFPATH . 'admin/admin-header.php' );
?>
<h3 class="feature-notice">Notice: Ads Management coming soon...</h3>

<?php include( DDFPATH . 'admin/admin-footer.php' ); ?>

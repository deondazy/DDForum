</div><!-- #main -->
</div><!-- #admin-body -->
</div><!-- #admin-content -->

<div id="admin-footer">Footer info</div>
</body>
</html>
<?php
/**
 * Logged user profile screen
 *
 * @package DDForum
 * @subpackage Administration
 */

define('CURRENT_PROFILE', true);

include(dirname(__FILE__) .'/user.php');

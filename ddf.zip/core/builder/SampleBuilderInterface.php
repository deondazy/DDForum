<?php

namespace DDForum\Core\Builder;

interface SampleBuilderInterface
{
  public function build(array $sample);
}

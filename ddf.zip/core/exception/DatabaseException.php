<?php

namespace DDForum\Core\Exception;

class DatabaseException extends DDFException
{
}

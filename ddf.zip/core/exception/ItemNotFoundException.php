<?php

namespace DDForum\Core\Exception;

class ItemNotFoundException extends DDFException
{
}

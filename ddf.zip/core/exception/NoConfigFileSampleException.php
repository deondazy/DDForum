<?php

namespace DDForum\Core\Exception;

class NoConfigFileSampleException extends DDFException
{
}

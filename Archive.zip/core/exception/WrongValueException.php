<?php

namespace DDForum\Core\Exception;

class WrongValueException extends DDFException
{
}

<?php

class Skin
{
    //
}

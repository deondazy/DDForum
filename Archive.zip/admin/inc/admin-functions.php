<?php
/**
 * Admin Functions
 *
 * @package DDFoprum
 */